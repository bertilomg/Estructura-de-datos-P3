#include <iostream>
#include <string>

using namespace std;


class CuentaBancaria {
	private:
		string numeroCuenta;
		string nombreTitular;
		double saldo;
	
	public:
		CuentaBancaria(string numeroC, string nombreT, double saldo);
		double getSaldo();
		string getnombreTitular();
		string getnumeroCuenta();
		void retirarCuenta(double importeRetiro);
		void depositarCuenta(double importeDeposito);
		

};
CuentaBancaria::CuentaBancaria(string numeroC, string nombreT, double saldo){
	
	this->numeroCuenta = numeroC;
	this->nombreTitular = nombreT;
	
	if(saldo < 0){
		this->saldo = 0.00;
	}else{
		this->saldo = saldo;
	}
	 
}

double CuentaBancaria::getSaldo(){
	return this->saldo;
}

string CuentaBancaria::getnumeroCuenta(){
	return this->numeroCuenta; 
}

string CuentaBancaria::getnombreTitular(){
	return this->nombreTitular;
}


void CuentaBancaria::retirarCuenta(double importeRetiro){
	
	if((this->saldo > 0) && (importeRetiro < this->saldo) && (importeRetiro > 0)){
		
		this->saldo -= importeRetiro;
	}
	else{
		cout << "! Retiro no valido " << endl;
	}
}


void CuentaBancaria::depositarCuenta(double importeDeposito){
	
	if(importeDeposito > 0){
		this->saldo += importeDeposito; 
	}
}


int main(){
	
	CuentaBancaria cuenta("SLV654567", "Bertilo Munoz", 500.00);
	cout << "Titular de la cuenta: " << cuenta.getnombreTitular() << endl;
	cout << "No Cuenta: " << cuenta.getnumeroCuenta() << endl;
	cout << "Saldo: $" << cuenta.getSaldo() << endl;
	cout << "---------------------------------------------" << endl;
	cout << endl;
	
	CuentaBancaria cuentaAmigo("SLV976568", "Jaime Lopez", 9767.00);
	cout << "Titular de la cuenta: " << cuentaAmigo.getnombreTitular() << endl;
	cout << "No Cuenta: " << cuentaAmigo.getnumeroCuenta() << endl;
	cout << "Saldo: $" << cuentaAmigo.getSaldo() << endl;
	cout << "-------------------------------------------" << endl;
	cout << endl;
	
	CuentaBancaria cuentaNoValida("SVL076511", "Luciana Sandoval", -500.00);
	cout << "Titular de la cuenta: " << cuentaNoValida.getnombreTitular() << endl;
	cout << "No Cuenta: " << cuentaNoValida.getnumeroCuenta() << endl;
	cout << "Saldo: $" << cuentaNoValida.getSaldo() << endl;
	cout << "--------------------------------------------" << endl;
	cout << endl;
	cout << endl;

		cout << "Quiero retirar $35 de la cuenta " << cuenta.getnumeroCuenta() << endl;
	cout << "Saldo inicial: $" << cuenta.getSaldo() << endl;
	cuenta.retirarCuenta(35);
	cout << "Saldo despues del retiro: $" << cuenta.getSaldo() << endl;
	cout << "--------------------------------------------" << endl;
	cout << endl;
	
	cout << "Quiero retirar $500 de la cuenta " << cuenta.getnumeroCuenta() << endl;
	cout << "Saldo inicial: $" << cuenta.getSaldo() << endl;
	cuenta.retirarCuenta(500);
	cout << "Saldo despues del retiro: $" << cuenta.getSaldo() << endl;
	cout << "--------------------------------------------" << endl;
	cout << endl;
	
	
	cout << "Quiero retirar -$125 de la cuenta " << cuenta.getnumeroCuenta() << endl;
	cout << "Saldo inicial: $" << cuenta.getSaldo() << endl;
	cuenta.retirarCuenta(-125);
	cout << "Saldo despues del retiro: $" << cuenta.getSaldo() << endl;
	cout << "--------------------------------------------" << endl;
	cout << endl;
	
	cout << "Quiero depositar $125 de la cuenta " << cuenta.getnumeroCuenta() << endl;
	cout << "Saldo inicial: $" << cuenta.getSaldo() << endl;
	cuenta.depositarCuenta(125);
	cout << "Saldo despues del retiro: $" << cuenta.getSaldo() << endl;
	cout << "--------------------------------------------" << endl;
	cout << endl;
	
	cout << "Quiero retirar -$300 de la cuenta " << cuenta.getnumeroCuenta() << endl;
	cout << "Saldo inicial: $" << cuenta.getSaldo() << endl;
	cuenta.depositarCuenta(-300);
	cout << "Saldo despues del retiro: $" << cuenta.getSaldo() << endl;
	cout << "--------------------------------------------" << endl;
	cout << endl;
	
	return 0;
}

